package com.avjajodia.beacon


/**
 * Created by Aditya V Jajodia on 28-01-2019.
 */
data class BeaconData(val id: String, val distance: Double)