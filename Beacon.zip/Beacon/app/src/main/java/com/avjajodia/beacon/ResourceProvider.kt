package com.avjajodia.beacon

import android.content.Context


/**
 * Created by Aditya V Jajodia on 28-01-2019.
 */
class ResourceProvider {

    fun getApplicationContext(): Context? {
        return BeaconApplication.instance?.applicationContext
    }

}