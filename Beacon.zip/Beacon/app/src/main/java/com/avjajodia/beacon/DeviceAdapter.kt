package com.avjajodia.beacon

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.recycler_list_item.view.*


/**
 * Created by Aditya V Jajodia on 27-01-2019.
 */
class DeviceAdapter(private val deviceList: MutableList<BeaconData>) :
    RecyclerView.Adapter<DeviceAdapter.Viewholder>() {

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): Viewholder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.recycler_list_item, parent, false)
        return Viewholder(v)
    }

    override fun getItemCount(): Int {
        return deviceList.size
    }

    override fun onBindViewHolder(holder: Viewholder, position: Int) {

        val singleItem = deviceList[position]
        holder.itemView.device_id.text = singleItem.id
        holder.itemView.device_distance.text = singleItem.distance.toString()

    }


    inner class Viewholder(itemView: View) : RecyclerView.ViewHolder(itemView)
}