package com.avjajodia.beacon

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.devices_fragment.view.*


class DevicesFragment : Fragment() {


    private lateinit var viewModel: DevicesViewModel
    private var deviceList = mutableListOf<BeaconData>()
    private val deviceAdapter = DeviceAdapter(deviceList)

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val view = inflater.inflate(R.layout.devices_fragment, container, false)
        view.devices_list.adapter = deviceAdapter
        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        viewModel = ViewModelProviders.of(this).get(DevicesViewModel::class.java)

        viewModel.deviceList().observe(this,
            Observer<List<BeaconData>> { it ->
                deviceList = it as MutableList<BeaconData>
                deviceAdapter.notifyDataSetChanged()
            })
    }
}
