package com.avjajodia.beacon

import android.app.Application
import android.arch.lifecycle.AndroidViewModel
import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.RemoteException
import android.util.Log
import org.altbeacon.beacon.*

class DevicesViewModel : ViewModel(), BeaconConsumer {

    private var resourceProvider: ResourceProvider = ResourceProvider()
    private val beaconManager: BeaconManager =
        BeaconManager.getInstanceForApplication(resourceProvider.getApplicationContext()!!)

    var list: MutableList<BeaconData> = mutableListOf()
    private var deviceList: MutableLiveData<List<BeaconData>>

    init {
        beaconManager.beaconParsers.add(BeaconParser().setBeaconLayout("m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24"))
        beaconManager.beaconParsers.add(BeaconParser().setBeaconLayout("m:2-3=beac,i:4-19,i:20-21,i:22-23,p:24-24,d:25-25"))
        beaconManager.bind(this)
        deviceList = MutableLiveData()
    }

    override fun getApplicationContext(): Context {
        return resourceProvider.getApplicationContext()!!
    }

    override fun unbindService(p0: ServiceConnection?) {
        //beaconManager.unbind(this)
    }

    override fun bindService(p0: Intent?, p1: ServiceConnection?, p2: Int): Boolean {
        return true
    }

    override fun onBeaconServiceConnect() {
        //beaconManager.removeAllRangeNotifiers()

        val rangeNotifier = RangeNotifier { beacons, region ->
            if (beacons.isNotEmpty()) {
                val firstBeacon = beacons.iterator().next()
                Log.d("ViewModel", "Beacon Size ${beacons.size}")
                list.add(BeaconData(firstBeacon.id1.toString(), firstBeacon.distance))
                deviceList.value = list
                // firstBeacon.distance
                // firstBeacon.toString
            }
        }
        try {
            beaconManager.startRangingBeaconsInRegion(Region("myRangingUniqueId", null, null, null))
            beaconManager.addRangeNotifier(rangeNotifier)
            beaconManager.startRangingBeaconsInRegion(Region("myRangingUniqueId", null, null, null))
            beaconManager.addRangeNotifier(rangeNotifier)
        } catch (e: RemoteException) {
            e.printStackTrace()
        }

    }

    override fun onCleared() {
        super.onCleared()
        beaconManager.unbind(this)
    }

    fun deviceList(): LiveData<List<BeaconData>> {
        return deviceList
    }

}
