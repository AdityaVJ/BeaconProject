package com.avjajodia.beacon

import android.app.Application
import android.content.Context


/**
 * Created by Aditya V Jajodia on 28-01-2019.
 */
class BeaconApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        @get:Synchronized
        var instance: BeaconApplication? = null
            private set
    }
}